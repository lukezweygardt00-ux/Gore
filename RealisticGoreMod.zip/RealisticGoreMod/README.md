# Realistic Gore (Minecraft 1.7.10, Forge 10.13.4.1614)

* **Hitting a mob (melee, by a player)**
  * Weapon (sword, axe/pickaxe/shovel, any item with an attack-damage bonus): lots of
    *breaking red wool* particles + `sword_hit` sound. Harder hits = more blood.
  * Fists / non-weapon items: only a few red-wool particles + `punch_hit` sound.
* **Mob dies** (any cause, every mob except players and bosses)
  * Death sound `gore_explode` + a big red-wool blood burst.
  * The mob is replaced by a tumbling **ragdoll corpse** (bounces, slides, settles on its
    side, then fades out). The corpse is a copy of the real mob (sheep colour, baby zombies,
    armor, etc. are kept).
  * **Organs** (heart, lungs, intestines, liver, stomach, kidney, brain - pixel art) fly out,
    bounce with physics, leave blood splashes + squish sounds, then fade away.
  * **Skeletons / wither skeletons / skeleton horses**: ragdoll only, no organs.

## Tweaking
* Lifetimes: `LIFE` / `FADE` in `EntityCorpse.java` and `EntityOrgan.java` (ticks, 20 = 1 s).
* Amount of organs: `onDeath` in `GoreEvents.java`.
* Amount of blood on hit: `onHurt` in `GoreEvents.java`.
* Sounds: replace the .ogg files in `assets/realgore/sounds/` (must be .ogg, ideally mono).
* Organ art: `assets/realgore/textures/entity/organ_*.png` (16x16).
