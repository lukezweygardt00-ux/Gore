package com.realgore;

import cpw.mods.fml.common.registry.IEntityAdditionalSpawnData;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

/** A flying chunk of gore (heart, lungs, ...) with simple bounce physics that fades away. */
public class EntityOrgan extends Entity implements IEntityAdditionalSpawnData {
    public static final String[] NAMES = {"heart", "lungs", "intestines", "liver", "stomach", "kidney", "brain"};
    public static final float[] SIZES = {0.30F, 0.42F, 0.46F, 0.40F, 0.34F, 0.26F, 0.32F};
    public static final int TYPES = NAMES.length;

    public static final int LIFE = 200;
    public static final int FADE = 40;

    public int type;
    public int age;
    public float yawOffset;

    // client-side tumble state
    public float roll, prevRoll, pitch, prevPitch;
    private float spinRoll, spinPitch;

    public EntityOrgan(World world) {
        super(world);
        setSize(0.2F, 0.12F);
        yawOffset = rand.nextFloat() * 360.0F;
        spinRoll = (rand.nextBoolean() ? 1 : -1) * (15 + rand.nextInt(30));
        spinPitch = (rand.nextBoolean() ? 1 : -1) * (15 + rand.nextInt(30));
    }

    public EntityOrgan(World world, double x, double y, double z, int type) {
        this(world);
        this.type = type;
        setPosition(x, y, z);
    }

    @Override
    protected void entityInit() {
        dataWatcher.addObject(16, Byte.valueOf((byte) 1)); // 1 = airborne
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        age++;

        if (worldObj.isRemote) {
            prevRoll = roll;
            prevPitch = pitch;
            if (dataWatcher.getWatchableObjectByte(16) != 0) {
                roll += spinRoll;
                pitch += spinPitch;
            } else {
                roll = approach(roll, Math.round(roll / 180.0F) * 180.0F, 25.0F);
                pitch = approach(pitch, Math.round(pitch / 180.0F) * 180.0F, 25.0F);
            }
            if (age > LIFE + 20) setDead();
            return;
        }

        if (age > LIFE) {
            setDead();
            return;
        }

        double startX = posX, startZ = posZ;
        motionY -= 0.04D;
        moveEntity(motionX, motionY, motionZ);

        if (isCollidedHorizontally) {
            if (Math.abs(posX - startX) < Math.abs(motionX) - 0.001D) motionX *= -0.4D;
            if (Math.abs(posZ - startZ) < Math.abs(motionZ) - 0.001D) motionZ *= -0.4D;
        }
        if (isCollidedVertically) {
            if (motionY < -0.2D) {
                motionY = -motionY * 0.35D;
                GoreEvents.blood(worldObj, posX, posY + 0.05D, posZ, 4, 0.1D, 0.03D, 0.1D, 0.05D);
                worldObj.playSoundAtEntity(this, "mob.slime.small", 0.35F, 0.6F + rand.nextFloat() * 0.3F);
            } else {
                motionY = 0.0D;
            }
        }

        motionX *= 0.98D;
        motionY *= 0.98D;
        motionZ *= 0.98D;
        if (onGround) {
            motionX *= 0.5D;
            motionZ *= 0.5D;
        }

        boolean air = !onGround;
        if ((dataWatcher.getWatchableObjectByte(16) != 0) != air) {
            dataWatcher.updateObject(16, Byte.valueOf((byte) (air ? 1 : 0)));
        }
    }

    private static float approach(float v, float target, float step) {
        float d = target - v;
        if (d > step) d = step;
        if (d < -step) d = -step;
        return v + d;
    }

    public float getAlpha(float partial) {
        float t = age + partial;
        float start = LIFE - FADE;
        if (t <= start) return 1.0F;
        float a = 1.0F - (t - start) / FADE;
        return a < 0.0F ? 0.0F : a;
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound tag) {
        setDead();
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound tag) {
    }

    @Override
    public void writeSpawnData(ByteBuf buf) {
        buf.writeInt(type);
    }

    @Override
    public void readSpawnData(ByteBuf buf) {
        type = buf.readInt();
        if (type < 0 || type >= TYPES) type = 0;
    }
}
