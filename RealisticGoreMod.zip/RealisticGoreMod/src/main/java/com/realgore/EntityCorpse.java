package com.realgore;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.common.registry.IEntityAdditionalSpawnData;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

/**
 * A tumbling "ragdoll" of the dead mob. Physics (gravity, bounce, friction) run on the
 * server; the client only tumbles the model while airborne and lets it settle on its side.
 */
public class EntityCorpse extends Entity implements IEntityAdditionalSpawnData {
    public static final int LIFE = 130;
    public static final int FADE = 30;

    public int age;
    public NBTTagCompound mobTag;
    public float mobHeight = 1.8F;
    public float mobWidth = 0.6F;

    // client-side tumble state
    public float roll, prevRoll, pitch, prevPitch;
    private float spinRoll, spinPitch;
    private EntityLivingBase dummy;
    private boolean dummyFailed;

    public EntityCorpse(World world) {
        super(world);
        setSize(0.5F, 0.5F);
        ignoreFrustumCheck = true;
        spinRoll = (rand.nextBoolean() ? 1 : -1) * (14 + rand.nextInt(20));
        spinPitch = (rand.nextBoolean() ? 1 : -1) * rand.nextInt(22);
    }

    public EntityCorpse(World world, EntityLiving mob) {
        this(world);
        mobHeight = mob.height;
        mobWidth = mob.width;
        mobTag = new NBTTagCompound();
        mob.writeToNBT(mobTag);
        mobTag.setString("id", EntityList.getEntityString(mob));
        mobTag.removeTag("Riding");
        mobTag.removeTag("Leash");
        setLocationAndAngles(mob.posX, mob.posY, mob.posZ, mob.renderYawOffset, 0.0F);
    }

    @Override
    protected void entityInit() {
        dataWatcher.addObject(16, Byte.valueOf((byte) 1)); // 1 = airborne
    }

    // ---------------------------------------------------------------- update
    @Override
    public void onUpdate() {
        super.onUpdate();
        age++;

        if (worldObj.isRemote) {
            clientTick();
            if (age > LIFE + 20) setDead();
            return;
        }

        if (age > LIFE) {
            setDead();
            return;
        }

        double startX = posX, startZ = posZ;
        motionY -= 0.04D;
        moveEntity(motionX, motionY, motionZ);

        // bounce off walls
        if (isCollidedHorizontally) {
            if (Math.abs(posX - startX) < Math.abs(motionX) - 0.001D) motionX *= -0.45D;
            if (Math.abs(posZ - startZ) < Math.abs(motionZ) - 0.001D) motionZ *= -0.45D;
        }
        // bounce off floor / ceiling
        if (isCollidedVertically) {
            if (motionY < -0.22D) {
                motionY = -motionY * 0.38D;
                GoreEvents.blood(worldObj, posX, posY + 0.1D, posZ, 6, 0.2D, 0.05D, 0.2D, 0.06D);
            } else {
                motionY = 0.0D;
            }
        }

        motionX *= 0.98D;
        motionY *= 0.98D;
        motionZ *= 0.98D;
        if (onGround) {
            motionX *= 0.6D;
            motionZ *= 0.6D;
        }

        boolean air = !onGround;
        if ((dataWatcher.getWatchableObjectByte(16) != 0) != air) {
            dataWatcher.updateObject(16, Byte.valueOf((byte) (air ? 1 : 0)));
        }
    }

    private void clientTick() {
        prevRoll = roll;
        prevPitch = pitch;
        if (dataWatcher.getWatchableObjectByte(16) != 0) {
            roll += spinRoll;
            pitch += spinPitch;
        } else {
            // settle lying on the ground
            float restRoll = Math.round((roll - 90.0F) / 180.0F) * 180.0F + 90.0F;
            float restPitch = Math.round(pitch / 180.0F) * 180.0F;
            roll = approach(roll, restRoll, 22.0F);
            pitch = approach(pitch, restPitch, 22.0F);
        }
    }

    private static float approach(float v, float target, float step) {
        float d = target - v;
        if (d > step) d = step;
        if (d < -step) d = -step;
        return v + d;
    }

    public float getAlpha(float partial) {
        float t = age + partial;
        float start = LIFE - FADE;
        if (t <= start) return 1.0F;
        float a = 1.0F - (t - start) / FADE;
        return a < 0.0F ? 0.0F : a;
    }

    /** Client only: a copy of the dead mob used purely for rendering. */
    public EntityLivingBase getDummy() {
        if (dummy == null && !dummyFailed) {
            try {
                Entity e = mobTag == null ? null : EntityList.createEntityFromNBT(mobTag, worldObj);
                if (e instanceof EntityLivingBase) {
                    dummy = (EntityLivingBase) e;
                    dummy.deathTime = 0;
                    dummy.hurtTime = 0;
                    dummy.isDead = false;
                    dummy.setHealth(dummy.getMaxHealth());
                    dummy.rotationYaw = dummy.prevRotationYaw = 0.0F;
                    dummy.rotationPitch = dummy.prevRotationPitch = 0.0F;
                    dummy.renderYawOffset = dummy.prevRenderYawOffset = 0.0F;
                    dummy.rotationYawHead = dummy.prevRotationYawHead = 0.0F;
                    dummy.limbSwing = 0.0F;
                    dummy.limbSwingAmount = dummy.prevLimbSwingAmount = 0.0F;
                } else {
                    dummyFailed = true;
                }
            } catch (Throwable t) {
                dummyFailed = true;
            }
        }
        if (dummy != null) dummy.ticksExisted = age;
        return dummy;
    }

    // ------------------------------------------------------------------- NBT
    @Override
    protected void readEntityFromNBT(NBTTagCompound tag) {
        setDead(); // corpses are never kept across world reloads
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound tag) {
    }

    @Override
    public void writeSpawnData(ByteBuf buf) {
        buf.writeFloat(mobHeight);
        buf.writeFloat(mobWidth);
        ByteBufUtils.writeTag(buf, mobTag == null ? new NBTTagCompound() : mobTag);
    }

    @Override
    public void readSpawnData(ByteBuf buf) {
        mobHeight = buf.readFloat();
        mobWidth = buf.readFloat();
        mobTag = ByteBufUtils.readTag(buf);
    }
}
