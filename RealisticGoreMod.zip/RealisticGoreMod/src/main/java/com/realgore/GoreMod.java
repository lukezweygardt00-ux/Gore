package com.realgore;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.EntityRegistry;
import net.minecraftforge.common.MinecraftForge;

@Mod(modid = GoreMod.MODID, name = "Realistic Gore", version = "1.0.0")
public class GoreMod {
    public static final String MODID = "realgore";

    @Mod.Instance(MODID)
    public static GoreMod instance;

    @SidedProxy(clientSide = "com.realgore.ClientProxy", serverSide = "com.realgore.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        EntityRegistry.registerModEntity(EntityCorpse.class, "GoreCorpse", 0, this, 80, 1, true);
        EntityRegistry.registerModEntity(EntityOrgan.class, "GoreOrgan", 1, this, 64, 1, true);
        MinecraftForge.EVENT_BUS.register(new GoreEvents());
        proxy.registerClient();
    }
}
