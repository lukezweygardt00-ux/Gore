package com.realgore;

public class CommonProxy {
    public void registerClient() {
    }
}
