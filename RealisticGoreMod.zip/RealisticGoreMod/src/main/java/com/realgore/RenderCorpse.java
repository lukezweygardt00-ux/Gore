package com.realgore;

import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class RenderCorpse extends Render {
    @Override
    public void doRender(Entity entity, double x, double y, double z, float yaw, float partial) {
        EntityCorpse corpse = (EntityCorpse) entity;
        EntityLivingBase dummy = corpse.getDummy();
        if (dummy == null) return;
        Render render = RenderManager.instance.getEntityRenderObject(dummy);
        if (render == null) return;

        float alpha = corpse.getAlpha(partial);
        if (alpha <= 0.0F) return;

        float roll = corpse.prevRoll + (corpse.roll - corpse.prevRoll) * partial;
        float pitch = corpse.prevPitch + (corpse.pitch - corpse.prevPitch) * partial;

        int light = corpse.getBrightnessForRender(partial);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) (light % 65536), (float) (light / 65536));

        GL11.glPushMatrix();
        GL11.glTranslated(x, y + 0.25D, z);
        GL11.glRotatef(-corpse.rotationYaw, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(roll, 0.0F, 0.0F, 1.0F);
        GL11.glRotatef(pitch, 1.0F, 0.0F, 0.0F);
        GL11.glTranslated(0.0D, -corpse.mobHeight / 2.0D, 0.0D);

        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha);
        render.doRender(dummy, 0.0D, 0.0D, 0.0D, 0.0F, partial);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    @Override
    protected ResourceLocation getEntityTexture(Entity entity) {
        return null;
    }
}
