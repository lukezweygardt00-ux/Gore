package com.realgore;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class RenderOrgan extends Render {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[EntityOrgan.TYPES];

    static {
        for (int i = 0; i < EntityOrgan.TYPES; i++) {
            TEXTURES[i] = new ResourceLocation(GoreMod.MODID, "textures/entity/organ_" + EntityOrgan.NAMES[i] + ".png");
        }
    }

    @Override
    public void doRender(Entity entity, double x, double y, double z, float yaw, float partial) {
        EntityOrgan organ = (EntityOrgan) entity;
        float alpha = organ.getAlpha(partial);
        if (alpha <= 0.0F) return;

        float roll = organ.prevRoll + (organ.roll - organ.prevRoll) * partial;
        float pitch = organ.prevPitch + (organ.pitch - organ.prevPitch) * partial;
        float size = EntityOrgan.SIZES[organ.type] / 2.0F;

        bindTexture(TEXTURES[organ.type]);

        GL11.glPushMatrix();
        GL11.glTranslated(x, y + 0.03D, z);
        GL11.glRotatef(organ.yawOffset, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(roll, 0.0F, 0.0F, 1.0F);
        GL11.glRotatef(pitch, 1.0F, 0.0F, 0.0F);

        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_CULL_FACE);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        Tessellator t = Tessellator.instance;
        t.startDrawingQuads();
        t.setBrightness(organ.getBrightnessForRender(partial));
        t.setColorRGBA_F(1.0F, 1.0F, 1.0F, alpha);
        // flat quad lying in the XZ plane
        t.addVertexWithUV(-size, 0.0D, -size, 0.0D, 0.0D);
        t.addVertexWithUV(-size, 0.0D, size, 0.0D, 1.0D);
        t.addVertexWithUV(size, 0.0D, size, 1.0D, 1.0D);
        t.addVertexWithUV(size, 0.0D, -size, 1.0D, 0.0D);
        t.draw();

        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_CULL_FACE);
        GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glPopMatrix();
    }

    @Override
    protected ResourceLocation getEntityTexture(Entity entity) {
        return TEXTURES[((EntityOrgan) entity).type];
    }
}
