package com.realgore;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraftforge.client.event.RenderLivingEvent;

/** Hides the vanilla death animation: the ragdoll corpse entity takes over. */
public class ClientEvents {
    @SubscribeEvent
    public void onRenderLiving(RenderLivingEvent.Pre event) {
        EntityLivingBase e = event.entity;
        if (e.deathTime > 0 && GoreEvents.usesGoreDeath(e)) {
            event.setCanceled(true);
        }
    }
}
