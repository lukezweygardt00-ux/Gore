package com.realgore;

import com.google.common.collect.Multimap;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import java.util.Random;

public class GoreEvents {
    public static final String BLOOD = "blockcrack_35_14"; // breaking RED wool (block 35, meta 14)
    private static final Random RAND = new Random();

    /** Every non-player, non-boss mob gets the ragdoll death. */
    public static boolean usesGoreDeath(EntityLivingBase e) {
        return e instanceof EntityLiving
                && !(e instanceof IBossDisplayData)
                && EntityList.getEntityString(e) != null;
    }

    /** Skeletons (and skeleton horses) just ragdoll: no organs. */
    public static boolean hasOrgans(EntityLivingBase e) {
        if (e instanceof EntitySkeleton) return false;
        if (e instanceof EntityHorse && ((EntityHorse) e).getHorseType() == 4) return false;
        return true;
    }

    public static void blood(World w, double x, double y, double z, int count,
                             double spreadX, double spreadY, double spreadZ, double speed) {
        if (w instanceof WorldServer) {
            ((WorldServer) w).func_147487_a(BLOOD, x, y, z, count, spreadX, spreadY, spreadZ, speed);
        }
    }

    private static boolean isWeapon(ItemStack stack) {
        if (stack == null) return false;
        Item item = stack.getItem();
        if (item instanceof ItemSword || item instanceof ItemTool) return true;
        try {
            Multimap mods = stack.getAttributeModifiers();
            return mods != null && mods.containsKey(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName());
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------ hit
    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        EntityLivingBase target = event.entityLiving;
        World w = target.worldObj;
        if (w.isRemote || !(target instanceof EntityLiving) || event.ammount <= 0.0F) return;

        DamageSource src = event.source;
        if (!(src.getEntity() instanceof EntityPlayer) || !"player".equals(src.getDamageType())) return;

        EntityPlayer player = (EntityPlayer) src.getEntity();
        boolean weapon = isWeapon(player.getHeldItem());

        double x = target.posX;
        double y = target.posY + target.height * 0.6D;
        double z = target.posZ;
        double sx = target.width * 0.35D;
        double sy = target.height * 0.25D;

        if (weapon) {
            int count = (int) Math.min(16.0F + event.ammount * 3.0F, 55.0F);
            blood(w, x, y, z, count, sx, sy, sx, 0.12D);
            w.playSoundAtEntity(target, "realgore:sword_hit", 1.0F, 0.9F + RAND.nextFloat() * 0.2F);
        } else {
            blood(w, x, y, z, 5, sx * 0.6D, sy * 0.6D, sx * 0.6D, 0.06D);
            w.playSoundAtEntity(target, "realgore:punch_hit", 1.0F, 0.9F + RAND.nextFloat() * 0.2F);
        }
    }

    // ----------------------------------------------------------------- death
    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        EntityLivingBase target = event.entityLiving;
        World w = target.worldObj;
        if (w.isRemote || !usesGoreDeath(target)) return;

        // only once per mob
        if (target.getEntityData().getBoolean("realgore_done")) return;
        target.getEntityData().setBoolean("realgore_done", true);

        EntityLiving mob = (EntityLiving) target;

        // launch the corpse away from whatever killed it
        double vx = mob.motionX, vy = mob.motionY + 0.25D, vz = mob.motionZ;
        Entity attacker = event.source.getEntity();
        if (attacker != null) {
            double dx = mob.posX - attacker.posX;
            double dz = mob.posZ - attacker.posZ;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > 0.001D) {
                vx += dx / d * 0.35D;
                vz += dz / d * 0.35D;
            }
            vy += 0.15D;
        }

        EntityCorpse corpse = new EntityCorpse(w, mob);
        corpse.motionX = vx;
        corpse.motionY = vy;
        corpse.motionZ = vz;
        w.spawnEntityInWorld(corpse);

        double cx = mob.posX, cy = mob.posY + mob.height * 0.5D, cz = mob.posZ;
        w.playSoundAtEntity(mob, "realgore:gore_explode", 1.2F, 0.9F + RAND.nextFloat() * 0.2F);
        blood(w, cx, cy, cz, 70, mob.width * 0.5D, mob.height * 0.3D, mob.width * 0.5D, 0.18D);

        if (hasOrgans(mob)) {
            int count = (int) (5 + mob.width * mob.height * 3.0F);
            if (count > 16) count = 16;
            for (int i = 0; i < count; i++) {
                int type = RAND.nextInt(EntityOrgan.TYPES);
                double ox = cx + (RAND.nextDouble() - 0.5D) * mob.width * 0.6D;
                double oz = cz + (RAND.nextDouble() - 0.5D) * mob.width * 0.6D;
                double angle = RAND.nextDouble() * Math.PI * 2.0D;
                double speed = 0.12D + RAND.nextDouble() * 0.32D;
                EntityOrgan organ = new EntityOrgan(w, ox, cy, oz, type);
                organ.motionX = Math.cos(angle) * speed;
                organ.motionZ = Math.sin(angle) * speed;
                organ.motionY = 0.2D + RAND.nextDouble() * 0.45D;
                w.spawnEntityInWorld(organ);
            }
        }
    }
}
