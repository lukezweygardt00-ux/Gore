package com.realgore;

import cpw.mods.fml.client.registry.RenderingRegistry;
import net.minecraftforge.common.MinecraftForge;

public class ClientProxy extends CommonProxy {
    @Override
    public void registerClient() {
        RenderingRegistry.registerEntityRenderingHandler(EntityCorpse.class, new RenderCorpse());
        RenderingRegistry.registerEntityRenderingHandler(EntityOrgan.class, new RenderOrgan());
        MinecraftForge.EVENT_BUS.register(new ClientEvents());
    }
}
